<?php


interface IPage {

    function getPageContent();
    function setPageTitle($title);
    function getPageTitle();
    
    
}

?>
