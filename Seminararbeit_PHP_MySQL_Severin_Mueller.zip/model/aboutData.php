Im Mai 2013 wurde die Firma Hoch-Sicherheit GmbH mit Sitz in Schaffhausen gegründet. <br /><br />

Wir unterscheiden uns durch ein breites Know-How was die Recht im Bereich Sicherheit anbelangt sowie ein fundiertes Wissen in Krisensituationen. Durch ständige Aus- und Weiterbildungen sind unsere Mitarbeiter für jede Situation gewappnet. <br /><br />

Unser oberstes Gebot ist, heikle Situationen immer erst verbal zu schlichten. Wir scheuen uns aber nicht, auch körperlich einzugreifen wenn es die Situation verlangt. Wir stehen immer hinter unseren Kunden und stimmen unsere Diensleistungen auf ihre Bedürfnisse ab. <br /><br />

Unsere Kunden können sich sicher sein, dass kritische Situationen sofort erkannt und entsprechende Massnahmen getroffen werden. Bei Situationen die erkalieren wissen unsere Mitarbeiter genau, wie sie handeln müssen und fachgerechte Handgriffe einsetzen dürfen. 

