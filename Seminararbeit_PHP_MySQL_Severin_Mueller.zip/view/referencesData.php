	<td width="35%" class="maintext"><a class="main" href="http://www.randehueueler.ch/">Guggemusig Randeh&uuml;&uuml;ler</a></td>
	<td width="35%" class="maintext">Reto Schmid</td>
	<td width="15%" class="maintext">&nbsp;</td>
	<td width="15%" class="maintext">&nbsp;</td>
</tr>
<tr>
	<td width="35%" class="maintext"><a class="main" href="http://www.schmatzdiegurken.ch/">Guggemusig Schmatz die Gurken</a></td>
	<td width="35%" class="maintext">Kathrin Gertsch</td>
	<td width="15%" class="maintext">&nbsp;</td>
	<td width="15%" class="maintext">&nbsp;</td>
</tr>
<tr>
	<td width="35%" class="maintext"><a class="main" href="http://oetterlimanagement.ch/">Oetterli Management</a></td>
	<td width="35%" class="maintext">Matthias Oetterli</td>
	<td width="15%" class="maintext">&nbsp;</td>
	<td width="15%" class="maintext">&nbsp;</td>
</tr>
<tr>
	<td width="35%" class="maintext">Musikfest Schaffhausen</td>
	<td width="35%" class="maintext">Marcel Mannhart</td>
	<td width="15%" class="maintext">&nbsp;</td>
	<td width="15%" class="maintext">&nbsp;</td>
</tr>
<tr>
	<td width="35%" class="maintext">TV Beringen</td>
	<td width="35%" class="maintext">Daniel Spoerndli</td>
	<td width="15%" class="maintext">&nbsp;</td>
	<td width="15%" class="maintext">&nbsp;</td>
</tr>
