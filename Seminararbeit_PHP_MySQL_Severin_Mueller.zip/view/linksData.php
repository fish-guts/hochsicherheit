	<td width="35%" class="maintext"><a class="main" href="http://www.randehueueler.ch/">Guggemusig Randeh&uuml;&uuml;ler</a></td>
</tr>
<tr>
	<td width="35%" class="maintext"><a class="main" href="http://www.schmatzdiegurken.ch/">Guggemusig Schmatz die Gurken</a></td>
</tr>
<tr>
	<td width="35%" class="maintext"><a class="main" href="http://oetterlimanagement.ch/">Oetterli Management</a></td>
</tr>
