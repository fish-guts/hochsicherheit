<?php
ini_set('display_errors', 1);
error_reporting(~0);
interface Controller {

    function indexAction();
    
}
